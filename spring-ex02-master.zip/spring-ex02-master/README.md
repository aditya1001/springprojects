spring-ex02
===========

This example builds on spring-ex01, where Spring Java configuration files replaced the standard Spring MVC template XML files created by STS in Eclipse.  In addition, this code shows an end-to-end example of:

MySQL -> Hibernate -> Spring MVC -> JSP

This example has been validated with the following environment on MS Windows 7:

1. Eclipse Kepler
   1.1 Spring Tool Suite (STS) 3.4.0.RELEASE - for Kepler
2. Java SDK 1.7.0_51 (separate install)
3. Tomcat 7.0.50 (separate install)
4. Maven 3.0.5 (separate install)
5. MySQL 5.5.29
